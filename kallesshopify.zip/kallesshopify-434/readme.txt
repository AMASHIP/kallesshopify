Dear customer,

Thank you so much for choosing us. 
To get started with Kalles, you have two options:
1. One Click Demo Import with EcomRise application; guideline link https://support.the4.co/articles/import-demo#1-one-click-demo-import-with-ecomrise
2. Import Demo in the Theme; guideline link https://support.the4.co/articles/import-demo#2-import-demo-in-the-theme
-----------------------------------
Update
To update, please follow our document: 
1. Update theme with EcomRise application: https://support.the4.co/articles/update-the-theme#1-update-theme-with-ecomrise
2. Update theme in Theme actions by Edit code: https://support.the4.co/articles/update-the-theme#2-update-theme-in-theme-actions-by-edit-code
-----------------------------------
Change Log

https://support.the4.co/articles/kalles-changelog
Please carefully review the documentation and choose the method that suits you best. 
If you encounter any problems or have concerns, we encourage you to reach out to us via email at the4studio.net@gmail.com or through our support system: https://support.the4.co/

We will do our best to respond to your email/forum queries as promptly as possible. It is our privilege to assist you and provide the best support service.

Kind Regard